// ---------- state ----------
const DEFAULT_STATE = {
  mode: "dot",
  start: null,
  end: null,
  current: null,   // next number to check
  delay: 1000,
  scanning: false,
  matches: [],      // {dot, mc, legalName, dbaName, phone, address, status, operation}
};

let state = { ...DEFAULT_STATE };
let stopRequested = false;

const els = {
  mode: document.getElementById("mode"),
  start: document.getElementById("start"),
  end: document.getElementById("end"),
  delay: document.getElementById("delay"),
  findBtn: document.getElementById("findBtn"),
  stopBtn: document.getElementById("stopBtn"),
  resetBtn: document.getElementById("resetBtn"),
  recommendedBtn: document.getElementById("recommendedBtn"),
  exportBtn: document.getElementById("exportBtn"),
  status: document.getElementById("status"),
  result: document.getElementById("result"),
  log: document.getElementById("log"),
  count: document.getElementById("count"),
};

function save() {
  chrome.storage.local.set({ saferFinderState: state });
}

function renderLog() {
  els.count.textContent = state.matches.length + " match(es) found so far";
  els.log.innerHTML = state.matches
    .slice()
    .reverse()
    .map(function (m) {
      return "<div><b>" + (m.legalName || "(no name)") + "</b> — DOT " +
        (m.dot || "?") + (m.mc ? " / MC " + m.mc : "") + "</div>";
    })
    .join("");
}

function setStatus(text) {
  els.status.textContent = text;
}

function showResult(m) {
  const url = buildSnapshotUrl(m._mode, m._number);
  els.result.className = "match";
  els.result.innerHTML =
    "<b>MATCH — ACTIVE + Interstate</b>\n" +
    "Legal Name: " + (m.legalName || "") + "\n" +
    (m.dbaName ? "DBA: " + m.dbaName + "\n" : "") +
    "DOT Number: " + (m.dot || "") + "\n" +
    (m.mc ? "MC/MX: " + m.mc + "\n" : "") +
    "Phone: " + (m.phone || "") + "\n" +
    "Address: " + (m.address || "") + "\n" +
    '<a href="' + url + '" target="_blank">Open full SAFER page ↗ (copy remaining details here)</a>';
}

function clearResult() {
  els.result.className = "";
  els.result.style.display = "none";
  els.result.innerHTML = "";
}

// ---------- SAFER page fetching / parsing ----------

function buildSnapshotUrl(mode, number) {
  const param = mode === "mc" ? "MC" : "USDOT";
  return "https://safer.fmcsa.dot.gov/query.asp?searchtype=ANY&query_type=queryCarrierSnapshot&query_param=" + param + "&query_string=" + number;
}

// Find a table cell value by its label text, where the label is rendered
// as a real <a> link (this uniquely picks the actual field, since the
// on-page help text repeats these words as plain bold text, not links).
function getFieldByLabel(doc, labelText) {
  const anchors = Array.from(doc.querySelectorAll("a"));
  const labelAnchor = anchors.find(function (a) { return a.textContent.trim() === labelText; });
  if (!labelAnchor) return "";
  const td = labelAnchor.closest("td");
  if (!td) return "";
  const valueTd = td.nextElementSibling;
  return valueTd ? valueTd.textContent.trim().replace(/\s+/g, " ") : "";
}

function isInterstateChecked(doc) {
  const cells = Array.from(doc.querySelectorAll("td"));
  const interstateCell = cells.find(function (td) { return td.textContent.trim() === "Interstate"; });
  if (!interstateCell) return false;
  const marker = interstateCell.previousElementSibling;
  return !!marker && marker.textContent.trim().toUpperCase() === "X";
}

async function checkNumber(mode, number) {
  const url = buildSnapshotUrl(mode, number);
  const resp = await fetch(url);
  if (!resp.ok) return { found: false };
  const html = await resp.text();
  const doc = new DOMParser().parseFromString(html, "text/html");

  const bodyText = doc.body ? doc.body.textContent.toUpperCase() : "";
  if (bodyText.includes("RECORD NOT FOUND") || bodyText.includes("NO RECORDS MATCHING")) {
    return { found: false };
  }

  const status = getFieldByLabel(doc, "USDOT Status:").toUpperCase();
  const dotNumber = getFieldByLabel(doc, "USDOT Number:") || (mode === "dot" ? String(number) : "");
  const legalName = getFieldByLabel(doc, "Legal Name:");

  if (!legalName && !status) {
    return { found: false };
  }

  const interstate = isInterstateChecked(doc);

  if (status === "ACTIVE" && interstate) {
    return {
      found: true,
      match: {
        dot: dotNumber,
        mc: getFieldByLabel(doc, "MC/MX/FF Number(s):"),
        legalName: legalName,
        dbaName: getFieldByLabel(doc, "DBA Name:"),
        phone: getFieldByLabel(doc, "Phone:"),
        address: getFieldByLabel(doc, "Physical Address:"),
        _mode: mode,
        _number: number,
      },
    };
  }
  return { found: false };
}

// ---------- scan loop ----------

function delay(ms) {
  return new Promise(function (res) { setTimeout(res, ms); });
}

async function scanLoop() {
  stopRequested = false;
  state.scanning = true;
  els.findBtn.disabled = true;
  els.findBtn.textContent = "Scanning…";
  save();

  while (!stopRequested) {
    if (state.end && state.current > state.end) {
      setStatus("Reached end of range (" + state.end + ") with no further matches.");
      break;
    }

    setStatus("Checking " + state.mode.toUpperCase() + " " + state.current + "…");

    try {
      const result = await checkNumber(state.mode, state.current);
      if (result.found) {
        state.matches.push(result.match);
        state.current += 1;
        save();
        renderLog();
        showResult(result.match);
        setStatus("Match found. Review it below, then click Continue.");
        break;
      }
    } catch (e) {
      setStatus("Error checking " + state.current + ": " + e.message + " — skipping");
    }

    state.current += 1;
    save();
    await delay(Math.max(300, Number(els.delay.value) || 1000));
  }

  state.scanning = false;
  els.findBtn.disabled = false;
  els.findBtn.textContent = state.matches.length ? "Continue Searching" : "Find Next Active + Interstate";
  save();
}

// ---------- UI wiring ----------

function readInputsIntoState() {
  state.mode = els.mode.value;
  const startVal = parseInt(els.start.value, 10);
  const endVal = parseInt(els.end.value, 10);
  if (!Number.isNaN(startVal)) {
    state.start = startVal;
    if (state.current == null) state.current = startVal;
  }
  state.end = Number.isNaN(endVal) ? null : endVal;
  state.delay = Number(els.delay.value) || 1000;
}

els.recommendedBtn.addEventListener("click", function () {
  els.mode.value = "dot";
  els.start.value = 1599945;
  els.end.value = 2169615;
});

els.findBtn.addEventListener("click", function () {
  readInputsIntoState();
  if (state.current == null) {
    setStatus("Enter a starting number first.");
    return;
  }
  clearResult();
  scanLoop();
});

els.stopBtn.addEventListener("click", function () {
  stopRequested = true;
  setStatus("Stopped. Click Continue to resume from where you left off.");
});

els.resetBtn.addEventListener("click", function () {
  stopRequested = true;
  state = Object.assign({}, DEFAULT_STATE, { mode: els.mode.value });
  save();
  clearResult();
  setStatus("Progress reset.");
  els.findBtn.textContent = "Find Next Active + Interstate";
  renderLog();
});

els.exportBtn.addEventListener("click", function () {
  if (!state.matches.length) {
    setStatus("No matches yet to export.");
    return;
  }
  const header = ["DOT Number", "MC/MX", "Legal Name", "DBA Name", "Phone", "Address"];
  const rows = state.matches.map(function (m) {
    return [m.dot, m.mc, m.legalName, m.dbaName, m.phone, m.address];
  });
  const csv = [header].concat(rows)
    .map(function (r) {
      return r.map(function (v) { return '"' + String(v || "").replace(/"/g, '""') + '"'; }).join(",");
    })
    .join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "safer_leads.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
});

// ---------- init ----------

chrome.storage.local.get("saferFinderState", function (data) {
  if (data && data.saferFinderState) {
    state = Object.assign({}, DEFAULT_STATE, data.saferFinderState);
    els.mode.value = state.mode;
    if (state.start != null) els.start.value = state.start;
    if (state.end != null) els.end.value = state.end;
    els.delay.value = state.delay || 1000;
    els.findBtn.textContent = state.matches.length ? "Continue Searching" : "Find Next Active + Interstate";
    if (state.current != null) {
      setStatus("Resuming — next check will start at " + state.mode.toUpperCase() + " " + state.current + ".");
    }
    renderLog();
  }
});
